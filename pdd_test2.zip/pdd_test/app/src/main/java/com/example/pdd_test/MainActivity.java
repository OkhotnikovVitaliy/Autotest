package com.example.pdd_test;

import androidx.appcompat.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       

            toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            // Остальной код ниже не изменился
        }

    }

